
  # Projeto WWW - História da Web

  This is a code bundle for Projeto WWW - História da Web. The original project is available at https://www.figma.com/design/M0LNDBearI98kgnTN0kubT/Projeto-WWW---Hist%C3%B3ria-da-Web.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  